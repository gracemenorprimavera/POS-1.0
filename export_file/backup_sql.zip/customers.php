"customer_id","customer_name","contact_number","address","balance",
"1","juana","09261839622","","60",
"2","Kulit","09211234567","LB","0",
"3","Tonyang","09261234567","San Pedro","0",
