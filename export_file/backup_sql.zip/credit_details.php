"credit_id","item_code","division","quantity","price",
"3","1","grocery","1","9.65",
"4","2","grocery","1","63.75",
