"credit_id","customer_id","credit_date","total_amount",
