
<div id="report_menu">
	<ul>
	<?php
		echo '<li>'.anchor('', 'Daily Sales Summary').'</li>';
		
	?>
	</ul>
</div>