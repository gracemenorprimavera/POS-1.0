<div id="header">
	<?php echo $header; 
		if($header=='P.O.S.'){
			echo '<div id="subhead">'.$subheader.'</div>';
		}
	 ?>
</div>