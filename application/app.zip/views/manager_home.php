<div class="Home">
	<span>Generic <br>
		<b>P</b>oint <b>O</b>f <b>S</b>ale
	</span>
	<p> This system is able to record important business transaction and create daily reports.<br><br>
		Manager are the ones who manage transaction entrusted to them by the Admin.
	</p>
	<img src = "<?php echo base_url();?>img/cart.png" alt = "POS" />
</div>