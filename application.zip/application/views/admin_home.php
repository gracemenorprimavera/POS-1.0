<div class="Home">
	<span>Generic <br>
		<b>P</b>oint <b>O</b>f <b>S</b>ale
	</span>
	<p> This system is able to record important business transaction and create daily reports.<br><br>
		Administrator (Admin) are the ones who monitor/manage all of the records and reports in the system.
	</p>
	<img src = "<?php echo base_url();?>img/pos.png" alt = "POS" />
</div>